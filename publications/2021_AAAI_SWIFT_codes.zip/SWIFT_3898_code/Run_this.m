clc;
clear all;
close all;



path='./BBCDATA/'

addpath(genpath('./SWIFT'));
%you need to incorporate tensor_toolbox from https://www.sandia.gov/~tgkolda/TensorToolbox/index-2.6.html
addpath(genpath('./tensor_toolbox')); 

data_name='BBC';

COST={}
COST{1}= dlmread(fullfile(path,'DOC_COST.csv')); %Cost for Patients
COST{2}= dlmread(fullfile(path,'WORD_COST.csv')); %Cost for Diag
COST{1}=max(COST{1},0);
COST{2}=max(COST{2},0);
COST{3}=COST{2};

 X=read_input_count(path,'Tensor.csv');


R=5;


%%%%%%%%%%%%%%parallel computing%%%%%%%%%%%%%%%%%%%
PARFOR_FLAG=0;

 if(PARFOR_FLAG==1 &  isempty(gcp('nocreate')) )
                parpool('local',20)
 end
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%Algorithm Parameters%%%%%%%%%%%%%%%%%%

options.lambda = 100;
options.gamma = 0.5;
options.Total_iteration=10; %you can change this. 
options.sinkhorn_iter=20;  %you can change this. 

seed=1;


[output]=SWIFT(X,R,COST{1},COST{2},COST{3},options,seed,PARFOR_FLAG);








