function [ P ] = SWIFT( X,R, C1,C2,C3,options,seed,PARFOR )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here


%add packages
addpath(genpath('../../tensor_toolbox/'));
%--------------------------------------------------------------

%Initializing parameters 




size_pat=size(X,1);
size_diag=size(X,2);
size_med=size(X,3);


%Read the data

K={};
K{1} = exp(-options.lambda * C1 - 1);%Cost for Patients

%1
%length(K{1})
K{2} = exp(-options.lambda * C2 - 1); %Cost for Diag

%K{2}
%2
%length(K{2})
K{3} = exp(-options.lambda * C3 - 1); %Cost for Med

%2
%length(K{3})


Optimal_Trans={};
Factors={};
rng(seed);
Factors{1}=rand(size_pat,R);
Factors{2}=rand(size_diag,R);
Factors{3}=rand(size_med,R);



KRP={};
N=length(size(X));





%MATRICIZE THE INPUT
X_mat={};
Unique_nz_col={};

 for n=1:N
        %Matricizattion
        X_mat{n}=double(sptenmat(X, n));
        Unique_nz_col{n}=unique_col_ind(X_mat{n},0);
        %length(Unique_nz_col{n})
        Indexes=[1:n-1 n+1:N];
        khatt=khatrirao(Factors{Indexes(2)}, Factors{Indexes(1)});
        KRP{n}=khatt(Unique_nz_col{n},:);
 end






ITER=options.Total_iteration;



for itr=1:ITER
    itr

    
    for n=1:N
        
       
       [OT] = Update_OT(X_mat{n},Unique_nz_col{n}, R,K{n}, options, Factors{n}, KRP{n},PARFOR);
       Optimal_Trans{n}=OT';
       

    end
    
    [Factors,KRP]=Update_factor(Factors,Optimal_Trans,Unique_nz_col,KRP);
    for n=1:N
        KRP{n}=khatt(Unique_nz_col{n},:);
    end

    

    
end
% for n=1:N
%    Factors{n}=Factors{n}./sum(Factors{n}); 
% end

P = ktensor(Factors);



end

