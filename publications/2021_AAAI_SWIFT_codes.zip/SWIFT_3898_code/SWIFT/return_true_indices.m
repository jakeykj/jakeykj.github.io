function [ true_IDX ] = return_true_indices( chunks,elements )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

    true_IDX=reshape(bsxfun(@plus,chunks,elements.'),1,[]);
end

