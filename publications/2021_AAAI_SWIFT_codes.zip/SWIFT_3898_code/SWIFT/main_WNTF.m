%Importing the libraries

path='../../Dataset/Sutter_data/'
addpath(genpath('../../tensor_toolbox/'));



%Read the data
%COST={};
%COST{1}= dlmread(fullfile(path,'PAT_COST.csv')); %Cost for Patients
%COST{2}= dlmread(fullfile(path,'DIAG_COST.csv')); %Cost for Diag
%COST{3}= dlmread(fullfile(path,'MED_COST.csv')); %Cost for Med

PAR_DIAG_MED= dlmread(char(strcat(path,'PAT_DIAG_MED.csv')));
PAR_DIAG_MED=PAR_DIAG_MED(:,1:3);
idx=PAR_DIAG_MED;
K=size(unique(PAR_DIAG_MED(:,1)),1);
size_diag=size(unique(PAR_DIAG_MED(:,2)),1);
size_med=size(unique(PAR_DIAG_MED(:,3)),1);
vals = ones(size(idx,1),1);
siz = [K size_diag size_med ]
X = sptensor(idx,vals,siz);
normX=norm(X);


N=length(siz);


%Initializing parameters 
R=5;
gamma=0.5;

Factors={};
Factors{1}=rand(K,R);
Factors{2}=rand(size_diag,R);
Factors{3}=rand(size_med,R);


%Optimize the factor matrices

FIT=[];
P = ktensor(Factors);
normresidual=sqrt(normX^2 + norm(P)^2 - 2 * innerprod(X,P))
fit=1 - (normresidual / normX)%norm(matricized_X-(alpha'.*Z),'fro')

%cp_als_fit=cp_apr(X,5);
for itr=1:10

    for n=1:N

        %Matricizattion
        X_mat=double(sptenmat(X, n));

        Indexes=[1:n-1 n+1:N];
        KRP=khatrirao(Factors{Indexes(2)}, Factors{Indexes(1)});

        Factors{n}=SDNMF(X_mat, R,COST{n},gamma, Factors{n}, KRP )
        
        P = ktensor(Factors);
        normresidual=sqrt(normX^2 + norm(P)^2 - 2 * innerprod(X,P))
        fit=1 - (normresidual / normX);%norm(matricized_X-(alpha'.*Z),'fro')
        FIT=[FIT fit]


    end
end





