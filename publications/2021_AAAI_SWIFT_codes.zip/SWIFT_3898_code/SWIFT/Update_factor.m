function [Factors,KRP] = Update_factor(Factors,OT,Unique_nz_col,KRP)

N=size(Factors,1);

mFea1=size(Factors{1},1);
mFea2=size(Factors{2},1);
mFea3=size(Factors{3},1);
nSmp1=size(Factors{1},2);
nSmp2=size(Factors{2},2);
nSmp3=size(Factors{3},2);
R=size(Factors{1},2);

Delta_1_FULL=zeros(mFea2*mFea3,mFea1);
Delta_1_FULL(Unique_nz_col{1},: )=OT{1};

Delta_2_FULL=zeros(mFea1*mFea3,mFea2);
Delta_2_FULL(Unique_nz_col{2},: )=OT{2};

Delta_3_FULL=zeros(mFea1*mFea2,mFea3);
Delta_3_FULL(Unique_nz_col{3},: )=OT{3};





% ===================== update First Factor matrix ========================


KRP32=khatrirao(Factors{3}, Factors{2});
KRP{1}=KRP32;




D2 = permute(reshape(Delta_2_FULL, [mFea1, mFea3, mFea2]), [3, 2, 1]); %has same size as D1
D2_tilde = reshape(D2, [mFea2*mFea3,mFea1]);

D3=permute(reshape(Delta_3_FULL, [mFea1, mFea2, mFea3]), [2, 3, 1]); %has same size as D1
D3_tilde = reshape(D3, [mFea2*mFea3,mFea1]);




Factors{1}=KL_update_rule( [Delta_1_FULL;D2_tilde;D3_tilde] , [KRP32;KRP32;KRP32] , Factors{1}' )';

Factors{1}=Factors{1}./sum(Factors{1});

%Factors{1}=normc(Factors{1});




% ===================== update Second Factor matrix ========================

KRP31=khatrirao(Factors{3}, Factors{1});
KRP{2}=KRP31;


D1= permute(reshape(Delta_1_FULL, [mFea2, mFea3, mFea1]), [3, 2, 1]); %has same size as D2
D1_tilde = reshape(D1, [mFea1*mFea3,mFea2]);

D3= permute(reshape(Delta_3_FULL, [mFea1, mFea2, mFea3]), [1, 3, 2]); %has same size as D2
D3_tilde = reshape(D3, [mFea1*mFea3,mFea2]);


Factors{2}=KL_update_rule( [D1_tilde;Delta_2_FULL;D3_tilde] , [KRP31; KRP31; KRP31] ,Factors{2}' )';
Factors{2}=Factors{2}./sum(Factors{2});

%Factors{2}=normc(Factors{2});


% ===================== Update Third Factor matrix ========================

KRP21=khatrirao(Factors{2}, Factors{1});
KRP{3}=KRP21;

D1= permute(reshape(Delta_1_FULL, [mFea2, mFea3, mFea1]), [3, 1, 2]); %has same size as D3
D1_tilde = reshape(D1, [mFea1*mFea2,mFea3]);

D2 = permute(reshape(Delta_2_FULL, [mFea1, mFea3, mFea2]), [1, 3, 2]); %has same size as D3
D2_tilde = reshape(D2, [mFea1*mFea2,mFea3]);


%KL_left=(D1_tilde+D2_tilde+Delta_3_FULL)./3;

Factors{3}=KL_update_rule( [D1_tilde;D2_tilde;Delta_3_FULL] , [KRP21;KRP21;KRP21] ,Factors{3}' )';

Factors{3}=Factors{3}./sum(Factors{3});
%Factors{3}=normc(Factors{3});

%KRP{1}=khatrirao(Factors{3}, Factors{2});
%KRP{2}=khatrirao(Factors{3}, Factors{1});


